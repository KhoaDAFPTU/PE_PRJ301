/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Student;

/**
 *
 * @author Hoang Hiep
 */
public class StudentDAO extends DBContext{
    public ArrayList<Student> getStudentsByName(String name) {
        try {
            String sql = "SELECT * FROM Student WHERE name LIKE ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, "%" + name + "%");
            ResultSet rs = ps.executeQuery();
            
            ArrayList<Student> list = new ArrayList<>();
            while(rs.next()) {
                list.add(new Student(rs.getInt(1), rs.getString(2), rs.getBoolean(3), rs.getDate(4)));
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
