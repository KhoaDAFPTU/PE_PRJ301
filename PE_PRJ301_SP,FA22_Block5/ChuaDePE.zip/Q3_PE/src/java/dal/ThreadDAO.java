/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Account;
import model.Comment;

/**
 *
 * @author Hoang Hiep
 */
public class ThreadDAO extends DBContext{
    public ArrayList<model.Thread> getAllThread() {
        try {
            String sql = "SELECT * FROM Thread";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            ArrayList<model.Thread> threads = new ArrayList<>();
            while(rs.next()) {
                ArrayList<Comment> comments = (new CommentDAO()).getCommentsByThreadID(rs.getInt(1));
                threads.add(new model.Thread(rs.getInt(1), rs.getString(2), comments));
            }
            return threads;
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
