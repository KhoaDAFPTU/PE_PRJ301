/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Account;
import model.Comment;

/**
 *
 * @author Hoang Hiep
 */
public class CommentDAO extends DBContext{
    public ArrayList<Comment> getCommentsByThreadID(int threadID) {
        try {
            String sql = "SELECT c.cid, c.ctitle, a.displayname FROM Comment c\n" +
                        "  INNER JOIN Account a\n" +
                        "  ON c.userid = a.userid\n" +
                        "WHERE c.tid = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, threadID);
            ResultSet rs = ps.executeQuery();
            ArrayList<Comment> comment = new ArrayList<>();
            while(rs.next()) {
                comment.add(new Comment(rs.getInt(1), rs.getString(2), rs.getString(3)));
            }
            return comment;
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public void add(String ctitle, String userid, int tid) {
        try {
            String sql = "INSERT INTO Comment (ctitle, userid, tid) VALUES (?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, ctitle);
            ps.setString(2, userid);
            ps.setInt(3, tid);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
